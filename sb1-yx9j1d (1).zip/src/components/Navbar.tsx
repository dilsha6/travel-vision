import React from 'react';
import { Palm } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="bg-white border-b border-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Palm className="w-8 h-8 text-green-600" />
            <span className="font-semibold text-xl">Kerala Tourism</span>
          </div>
          
          <div className="flex items-center gap-6">
            <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Destinations</a>
            <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Experiences</a>
            <a href="#" className="text-gray-600 hover:text-green-600 transition-colors">Culture</a>
            <button className="bg-green-600 text-white rounded-lg py-2 px-4 hover:bg-green-700 transition-colors">
              Plan Your Trip
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}