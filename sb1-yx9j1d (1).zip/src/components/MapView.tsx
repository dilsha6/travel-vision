import React, { useEffect, useRef, useState } from 'react';
import { Wrapper } from '@googlemaps/react-wrapper';
import { keralaData } from '../data/keralaData';
import type { Destination } from '../data/keralaData';

const KERALA_CENTER = { lat: 10.8505, lng: 76.2711 };
const MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY'; // Replace with actual API key

interface MapProps {
  center: google.maps.LatLngLiteral;
  zoom: number;
  onMarkerClick?: (destination: Destination) => void;
}

function MapComponent({ center, zoom, onMarkerClick }: MapProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map>();
  const [markers, setMarkers] = useState<google.maps.Marker[]>([]);

  useEffect(() => {
    if (ref.current && !map) {
      const newMap = new google.maps.Map(ref.current, {
        center,
        zoom,
        styles: [
          {
            featureType: 'water',
            elementType: 'geometry',
            stylers: [{ color: '#e9e9e9' }, { lightness: 17 }]
          },
          {
            featureType: 'landscape',
            elementType: 'geometry',
            stylers: [{ color: '#f5f5f5' }, { lightness: 20 }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry',
            stylers: [{ color: '#dedede' }, { lightness: 21 }]
          }
        ]
      });
      setMap(newMap);
    }
  }, [ref, map, center, zoom]);

  useEffect(() => {
    if (map) {
      // Clear existing markers
      markers.forEach(marker => marker.setMap(null));
      
      // Create new markers for each destination
      const newMarkers = keralaData.destinations.map(destination => {
        const marker = new google.maps.Marker({
          position: destination.coordinates,
          map,
          title: destination.name,
          animation: google.maps.Animation.DROP,
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#059669',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          }
        });

        // Create info window
        const infoWindow = new google.maps.InfoWindow({
          content: `
            <div class="p-2">
              <h3 class="font-semibold">${destination.name}</h3>
              <p class="text-sm">${destination.description}</p>
            </div>
          `
        });

        // Add click listener
        marker.addListener('click', () => {
          infoWindow.open(map, marker);
          onMarkerClick?.(destination);
        });

        return marker;
      });

      setMarkers(newMarkers);
    }
  }, [map, onMarkerClick]);

  return <div ref={ref} className="w-full h-[500px] rounded-lg" />;
}

interface MapViewProps {
  onDestinationSelect?: (destination: Destination) => void;
}

export default function MapView({ onDestinationSelect }: MapViewProps) {
  return (
    <Wrapper apiKey={MAPS_API_KEY}>
      <MapComponent
        center={KERALA_CENTER}
        zoom={7}
        onMarkerClick={onDestinationSelect}
      />
    </Wrapper>
  );
}