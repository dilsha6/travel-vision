import React from 'react';
import { MapPin, Star } from 'lucide-react';
import type { Destination } from '../data/keralaData';

interface DestinationCardProps {
  destination: Destination;
  onClick: () => void;
}

export default function DestinationCard({ destination, onClick }: DestinationCardProps) {
  return (
    <div 
      onClick={onClick}
      className="group cursor-pointer overflow-hidden rounded-xl bg-white shadow-sm hover:shadow-md transition-all duration-300"
    >
      <div className="aspect-video w-full overflow-hidden">
        <img 
          src={destination.image} 
          alt={destination.name}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-gray-900">{destination.name}</h3>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm text-gray-600">{destination.rating}</span>
          </div>
        </div>
        <p className="mt-1 text-sm text-gray-600">{destination.description}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {destination.categories.map((category) => (
            <span 
              key={category}
              className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700"
            >
              {category}
            </span>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-2 text-sm text-gray-500">
          <MapPin className="w-4 h-4" />
          <span>Best time: {destination.bestTime}</span>
        </div>
      </div>
    </div>
  );
}