import { keralaData } from '../data/keralaData';

export function generateResponse(userInput: string): string {
  const input = userInput.toLowerCase();
  
  // Check for destination related queries
  const destinationMatch = keralaData.destinations.find(dest => 
    input.includes(dest.name.toLowerCase())
  );
  if (destinationMatch) {
    return `${destinationMatch.name} is ${destinationMatch.description}. Best time to visit is ${destinationMatch.bestTime}. Key attractions include: ${destinationMatch.highlights.join(', ')}.`;
  }

  // Check for cultural queries
  if (input.includes('culture') || input.includes('art') || input.includes('dance')) {
    return `Kerala has rich cultural heritage including art forms like ${keralaData.culture.artForms.join(', ')}. Major festivals include ${keralaData.culture.festivals.join(', ')}.`;
  }

  // Check for food related queries
  if (input.includes('food') || input.includes('cuisine') || input.includes('eat')) {
    return `Kerala cuisine is famous for dishes like ${keralaData.culture.cuisine.join(', ')}. The food is known for its use of coconut and spices.`;
  }

  // Check FAQs
  const faqMatch = keralaData.faqs.find(faq => 
    input.includes(faq.question.toLowerCase().split(' ').slice(1).join(' '))
  );
  if (faqMatch) {
    return faqMatch.answer;
  }

  // General response for travel planning
  if (input.includes('plan') || input.includes('visit') || input.includes('travel')) {
    return `I can help you plan your Kerala trip! Popular destinations include ${keralaData.destinations.map(d => d.name).join(', ')}. Would you like specific information about any of these places?`;
  }

  return "I can help you discover Kerala's beautiful destinations, culture, cuisine, and more. What would you like to know about?";
}