import React, { useState } from 'react';
import { Map, Palm, MessageSquare, PlusCircle, X } from 'lucide-react';
import Navbar from './components/Navbar';
import ChatAssistant from './components/ChatAssistant';
import MapView from './components/MapView';
import DestinationCard from './components/DestinationCard';
import { keralaData } from './data/keralaData';
import type { Destination } from './data/keralaData';
import type { Message } from './types';

function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Welcome to Kerala Tourism! I can help you discover the beauty of God\'s Own Country. Ask me about our destinations, culture, cuisine, or travel tips!'
    }
  ]);

  const toggleChat = () => setIsChatOpen(!isChatOpen);

  const handleSendMessage = (content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content
    };
    
    setMessages([...messages, newMessage]);
    
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: generateResponse(content)
      };
      setMessages(prev => [...prev, assistantMessage]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Palm className="w-5 h-5 text-green-600" />
                Kerala Destinations
              </h2>
              <button className="w-full bg-green-600 text-white rounded-lg py-2 px-4 flex items-center justify-center gap-2 hover:bg-green-700 transition-colors">
                <PlusCircle className="w-4 h-4" />
                Plan New Trip
              </button>
              
              <div className="mt-6 space-y-4">
                {keralaData.destinations.map((destination) => (
                  <DestinationCard
                    key={destination.id}
                    destination={destination}
                    onClick={() => setSelectedDestination(destination)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Main Content - Map & Details */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Map className="w-5 h-5 text-green-600" />
                {selectedDestination ? selectedDestination.name : 'Explore Kerala'}
              </h2>
              
              {selectedDestination ? (
                <div className="space-y-6">
                  <img
                    src={selectedDestination.image}
                    alt={selectedDestination.name}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                  <p className="text-gray-700 leading-relaxed">
                    {selectedDestination.longDescription}
                  </p>
                  
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Highlights</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {selectedDestination.highlights.map((highlight) => (
                        <div
                          key={highlight}
                          className="flex items-center gap-2 bg-green-50 p-2 rounded-lg"
                        >
                          <span className="w-2 h-2 bg-green-500 rounded-full" />
                          <span className="text-sm text-gray-700">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Activities</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {selectedDestination.activities.map((activity) => (
                        <div
                          key={activity}
                          className="flex items-center gap-2 bg-blue-50 p-2 rounded-lg"
                        >
                          <span className="w-2 h-2 bg-blue-500 rounded-full" />
                          <span className="text-sm text-gray-700">{activity}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <MapView onDestinationSelect={setSelectedDestination} />
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Chat Assistant Button */}
      <button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 bg-green-600 text-white rounded-full p-4 shadow-lg hover:bg-green-700 transition-colors"
      >
        {isChatOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageSquare className="w-6 h-6" />
        )}
      </button>

      {/* Chat Assistant Panel */}
      {isChatOpen && (
        <ChatAssistant
          messages={messages}
          onSendMessage={handleSendMessage}
        />
      )}
    </div>
  );
}

export default App;