export interface Destination {
  id: number;
  name: string;
  description: string;
  longDescription: string;
  image: string;
  highlights: string[];
  bestTime: string;
  activities: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
  rating: number;
  categories: string[];
}

export const keralaData = {
  destinations: [
    {
      id: 1,
      name: "Munnar",
      description: "A hill station known for its tea plantations and cool climate",
      longDescription: "Munnar, situated at the confluence of three mountain streams, is a haven of tranquility and natural beauty. The rolling hills covered in emerald-green tea plantations, the crisp mountain air, and the rich biodiversity make it one of Kerala's most sought-after destinations.",
      image: "https://images.unsplash.com/photo-1593693397690-362cb9666fc2?auto=format&fit=crop&w=800&q=80",
      highlights: [
        "Tea Gardens",
        "Eravikulam National Park",
        "Tea Museum",
        "Mattupetty Dam",
        "Echo Point",
        "Top Station",
        "Anamudi Peak"
      ],
      bestTime: "September to March",
      activities: [
        "Tea plantation tours",
        "Trekking",
        "Wildlife spotting",
        "Photography",
        "Tea tasting",
        "Mountain biking"
      ],
      coordinates: {
        lat: 10.0889,
        lng: 77.0595
      },
      rating: 4.8,
      categories: ["Hill Station", "Nature", "Wildlife"]
    },
    {
      id: 2,
      name: "Alleppey",
      description: "Famous for its backwaters, houseboats, and serene canals",
      longDescription: "Alleppey, also known as Alappuzha, is the Venice of the East. Its intricate network of canals, lagoons, and lakes forms the famous Kerala backwaters. The traditional houseboats, converted from old rice barges, offer a unique way to experience the region's natural beauty and cultural heritage.",
      image: "https://images.unsplash.com/photo-1593693411515-c20261bcad6e?auto=format&fit=crop&w=800&q=80",
      highlights: [
        "Houseboat cruises",
        "Alappuzha Beach",
        "Kuttanad Backwaters",
        "Marari Beach",
        "Pathiramanal Island",
        "Krishnapuram Palace"
      ],
      bestTime: "November to February",
      activities: [
        "Houseboat stays",
        "Canoeing",
        "Village tours",
        "Beach activities",
        "Bird watching",
        "Ayurvedic treatments"
      ],
      coordinates: {
        lat: 9.4981,
        lng: 76.3388
      },
      rating: 4.7,
      categories: ["Backwaters", "Beach", "Culture"]
    },
    {
      id: 3,
      name: "Wayanad",
      description: "Rich wildlife sanctuary and spice plantations",
      longDescription: "Wayanad is a picturesque plateau nestled in the Western Ghats. Known for its spice plantations, wildlife sanctuaries, and ancient caves, it offers a perfect blend of nature, adventure, and history. The region is also home to various indigenous tribes who maintain their traditional way of life.",
      image: "https://images.unsplash.com/photo-1593693411416-1e5a1638e8ef?auto=format&fit=crop&w=800&q=80",
      highlights: [
        "Chembra Peak",
        "Edakkal Caves",
        "Banasura Sagar Dam",
        "Wayanad Wildlife Sanctuary",
        "Pookode Lake",
        "Meenmutty Falls"
      ],
      bestTime: "October to May",
      activities: [
        "Cave exploration",
        "Wildlife safaris",
        "Bamboo rafting",
        "Spice plantation tours",
        "Tribal village visits",
        "Hiking"
      ],
      coordinates: {
        lat: 11.6854,
        lng: 76.1320
      },
      rating: 4.6,
      categories: ["Wildlife", "Adventure", "Nature"]
    },
    {
      id: 4,
      name: "Kovalam",
      description: "Iconic crescent beaches and lighthouse views",
      longDescription: "Kovalam is internationally renowned for its three adjacent crescent beaches. The lighthouse beach, with its striking 30-meter lighthouse, offers panoramic views of the Arabian Sea. The area is perfect for both relaxation and water sports, complemented by excellent seafood restaurants and ayurvedic centers.",
      image: "https://images.unsplash.com/photo-1593693397756-ef29b9e8cd3f?auto=format&fit=crop&w=800&q=80",
      highlights: [
        "Lighthouse Beach",
        "Hawa Beach",
        "Samudra Beach",
        "Vizhinjam Lighthouse",
        "Ayurvedic Spas",
        "Water Sports Center"
      ],
      bestTime: "September to March",
      activities: [
        "Sunbathing",
        "Swimming",
        "Surfing",
        "Ayurvedic treatments",
        "Catamaran rides",
        "Photography"
      ],
      coordinates: {
        lat: 8.4004,
        lng: 76.9787
      },
      rating: 4.5,
      categories: ["Beach", "Wellness", "Water Sports"]
    }
  ],
  culture: {
    artForms: [
      {
        name: "Kathakali",
        description: "Classical dance-drama known for elaborate costumes and makeup",
        image: "https://images.unsplash.com/photo-1593693397789-f4585e906875?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Mohiniyattam",
        description: "Classical dance form characterized by graceful movements",
        image: "https://images.unsplash.com/photo-1593693397823-5f6c71d82e9f?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Theyyam",
        description: "Ritual art form involving dance, music and elaborate costumes",
        image: "https://images.unsplash.com/photo-1593693397867-4923689c668e?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Kalaripayattu",
        description: "Ancient martial art form of Kerala",
        image: "https://images.unsplash.com/photo-1593693397890-362cb9666fc2?auto=format&fit=crop&w=800&q=80"
      }
    ],
    festivals: [
      {
        name: "Onam",
        description: "Harvest festival celebrating the mythical King Mahabali",
        time: "August-September",
        image: "https://images.unsplash.com/photo-1593693397912-4eb7b451b2a5?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Thrissur Pooram",
        description: "Famous temple festival with elephant processions",
        time: "April-May",
        image: "https://images.unsplash.com/photo-1593693397934-3c5c7f45849b?auto=format&fit=crop&w=800&q=80"
      }
    ],
    cuisine: [
      {
        name: "Kerala Sadya",
        description: "Traditional feast served on banana leaf",
        image: "https://images.unsplash.com/photo-1593693397956-3c5c7f45849d?auto=format&fit=crop&w=800&q=80"
      },
      {
        name: "Appam with Stew",
        description: "Lacy rice hoppers with coconut milk stew",
        image: "https://images.unsplash.com/photo-1593693397978-3c5c7f45849f?auto=format&fit=crop&w=800&q=80"
      }
    ]
  }
};